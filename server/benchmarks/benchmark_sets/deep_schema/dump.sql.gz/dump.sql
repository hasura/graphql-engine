--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3
-- Dumped by pg_dump version 14.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hdb_catalog; Type: SCHEMA; Schema: -; Owner: nicuveo
--

CREATE SCHEMA hdb_catalog;


ALTER SCHEMA hdb_catalog OWNER TO nicuveo;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: gen_hasura_uuid(); Type: FUNCTION; Schema: hdb_catalog; Owner: nicuveo
--

CREATE FUNCTION hdb_catalog.gen_hasura_uuid() RETURNS uuid
    LANGUAGE sql
    AS $$select gen_random_uuid()$$;


ALTER FUNCTION hdb_catalog.gen_hasura_uuid() OWNER TO nicuveo;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: hdb_action_log; Type: TABLE; Schema: hdb_catalog; Owner: nicuveo
--

CREATE TABLE hdb_catalog.hdb_action_log (
    id uuid DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    action_name text,
    input_payload jsonb NOT NULL,
    request_headers jsonb NOT NULL,
    session_variables jsonb NOT NULL,
    response_payload jsonb,
    errors jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    response_received_at timestamp with time zone,
    status text NOT NULL,
    CONSTRAINT hdb_action_log_status_check CHECK ((status = ANY (ARRAY['created'::text, 'processing'::text, 'completed'::text, 'error'::text])))
);


ALTER TABLE hdb_catalog.hdb_action_log OWNER TO nicuveo;

--
-- Name: hdb_cron_event_invocation_logs; Type: TABLE; Schema: hdb_catalog; Owner: nicuveo
--

CREATE TABLE hdb_catalog.hdb_cron_event_invocation_logs (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    event_id text,
    status integer,
    request json,
    response json,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE hdb_catalog.hdb_cron_event_invocation_logs OWNER TO nicuveo;

--
-- Name: hdb_cron_events; Type: TABLE; Schema: hdb_catalog; Owner: nicuveo
--

CREATE TABLE hdb_catalog.hdb_cron_events (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    trigger_name text NOT NULL,
    scheduled_time timestamp with time zone NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    tries integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    next_retry_at timestamp with time zone,
    CONSTRAINT valid_status CHECK ((status = ANY (ARRAY['scheduled'::text, 'locked'::text, 'delivered'::text, 'error'::text, 'dead'::text])))
);


ALTER TABLE hdb_catalog.hdb_cron_events OWNER TO nicuveo;

--
-- Name: hdb_metadata; Type: TABLE; Schema: hdb_catalog; Owner: nicuveo
--

CREATE TABLE hdb_catalog.hdb_metadata (
    id integer NOT NULL,
    metadata json NOT NULL,
    resource_version integer DEFAULT 1 NOT NULL
);


ALTER TABLE hdb_catalog.hdb_metadata OWNER TO nicuveo;

--
-- Name: hdb_scheduled_event_invocation_logs; Type: TABLE; Schema: hdb_catalog; Owner: nicuveo
--

CREATE TABLE hdb_catalog.hdb_scheduled_event_invocation_logs (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    event_id text,
    status integer,
    request json,
    response json,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE hdb_catalog.hdb_scheduled_event_invocation_logs OWNER TO nicuveo;

--
-- Name: hdb_scheduled_events; Type: TABLE; Schema: hdb_catalog; Owner: nicuveo
--

CREATE TABLE hdb_catalog.hdb_scheduled_events (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    webhook_conf json NOT NULL,
    scheduled_time timestamp with time zone NOT NULL,
    retry_conf json,
    payload json,
    header_conf json,
    status text DEFAULT 'scheduled'::text NOT NULL,
    tries integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    next_retry_at timestamp with time zone,
    comment text,
    CONSTRAINT valid_status CHECK ((status = ANY (ARRAY['scheduled'::text, 'locked'::text, 'delivered'::text, 'error'::text, 'dead'::text])))
);


ALTER TABLE hdb_catalog.hdb_scheduled_events OWNER TO nicuveo;

--
-- Name: hdb_schema_notifications; Type: TABLE; Schema: hdb_catalog; Owner: nicuveo
--

CREATE TABLE hdb_catalog.hdb_schema_notifications (
    id integer NOT NULL,
    notification json NOT NULL,
    resource_version integer DEFAULT 1 NOT NULL,
    instance_id uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT hdb_schema_notifications_id_check CHECK ((id = 1))
);


ALTER TABLE hdb_catalog.hdb_schema_notifications OWNER TO nicuveo;

--
-- Name: hdb_version; Type: TABLE; Schema: hdb_catalog; Owner: nicuveo
--

CREATE TABLE hdb_catalog.hdb_version (
    hasura_uuid uuid DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    version text NOT NULL,
    upgraded_on timestamp with time zone NOT NULL,
    cli_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    console_state jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE hdb_catalog.hdb_version OWNER TO nicuveo;

--
-- Name: t01; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t01 (
    id integer,
    name text
);


ALTER TABLE public.t01 OWNER TO nicuveo;

--
-- Name: t02; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t02 (
    id integer,
    name text
);


ALTER TABLE public.t02 OWNER TO nicuveo;

--
-- Name: t03; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t03 (
    id integer,
    name text
);


ALTER TABLE public.t03 OWNER TO nicuveo;

--
-- Name: t04; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t04 (
    id integer,
    name text
);


ALTER TABLE public.t04 OWNER TO nicuveo;

--
-- Name: t05; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t05 (
    id integer,
    name text
);


ALTER TABLE public.t05 OWNER TO nicuveo;

--
-- Name: t06; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t06 (
    id integer,
    name text
);


ALTER TABLE public.t06 OWNER TO nicuveo;

--
-- Name: t07; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t07 (
    id integer,
    name text
);


ALTER TABLE public.t07 OWNER TO nicuveo;

--
-- Name: t08; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t08 (
    id integer,
    name text
);


ALTER TABLE public.t08 OWNER TO nicuveo;

--
-- Name: t09; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t09 (
    id integer,
    name text
);


ALTER TABLE public.t09 OWNER TO nicuveo;

--
-- Name: t10; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t10 (
    id integer,
    name text
);


ALTER TABLE public.t10 OWNER TO nicuveo;

--
-- Name: t11; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t11 (
    id integer,
    name text
);


ALTER TABLE public.t11 OWNER TO nicuveo;

--
-- Name: t12; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t12 (
    id integer,
    name text
);


ALTER TABLE public.t12 OWNER TO nicuveo;

--
-- Name: t13; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t13 (
    id integer,
    name text
);


ALTER TABLE public.t13 OWNER TO nicuveo;

--
-- Name: t14; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t14 (
    id integer,
    name text
);


ALTER TABLE public.t14 OWNER TO nicuveo;

--
-- Name: t15; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t15 (
    id integer,
    name text
);


ALTER TABLE public.t15 OWNER TO nicuveo;

--
-- Name: t16; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t16 (
    id integer,
    name text
);


ALTER TABLE public.t16 OWNER TO nicuveo;

--
-- Name: t17; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t17 (
    id integer,
    name text
);


ALTER TABLE public.t17 OWNER TO nicuveo;

--
-- Name: t18; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t18 (
    id integer,
    name text
);


ALTER TABLE public.t18 OWNER TO nicuveo;

--
-- Name: t19; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t19 (
    id integer,
    name text
);


ALTER TABLE public.t19 OWNER TO nicuveo;

--
-- Name: t20; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t20 (
    id integer,
    name text
);


ALTER TABLE public.t20 OWNER TO nicuveo;

--
-- Name: t21; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t21 (
    id integer,
    name text
);


ALTER TABLE public.t21 OWNER TO nicuveo;

--
-- Name: t22; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t22 (
    id integer,
    name text
);


ALTER TABLE public.t22 OWNER TO nicuveo;

--
-- Name: t23; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t23 (
    id integer,
    name text
);


ALTER TABLE public.t23 OWNER TO nicuveo;

--
-- Name: t24; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t24 (
    id integer,
    name text
);


ALTER TABLE public.t24 OWNER TO nicuveo;

--
-- Name: t25; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t25 (
    id integer,
    name text
);


ALTER TABLE public.t25 OWNER TO nicuveo;

--
-- Name: t26; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t26 (
    id integer,
    name text
);


ALTER TABLE public.t26 OWNER TO nicuveo;

--
-- Name: t27; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t27 (
    id integer,
    name text
);


ALTER TABLE public.t27 OWNER TO nicuveo;

--
-- Name: t28; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t28 (
    id integer,
    name text
);


ALTER TABLE public.t28 OWNER TO nicuveo;

--
-- Name: t29; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t29 (
    id integer,
    name text
);


ALTER TABLE public.t29 OWNER TO nicuveo;

--
-- Name: t30; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t30 (
    id integer,
    name text
);


ALTER TABLE public.t30 OWNER TO nicuveo;

--
-- Name: t31; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t31 (
    id integer,
    name text
);


ALTER TABLE public.t31 OWNER TO nicuveo;

--
-- Name: t32; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t32 (
    id integer,
    name text
);


ALTER TABLE public.t32 OWNER TO nicuveo;

--
-- Name: t33; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t33 (
    id integer,
    name text
);


ALTER TABLE public.t33 OWNER TO nicuveo;

--
-- Name: t34; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t34 (
    id integer,
    name text
);


ALTER TABLE public.t34 OWNER TO nicuveo;

--
-- Name: t35; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t35 (
    id integer,
    name text
);


ALTER TABLE public.t35 OWNER TO nicuveo;

--
-- Name: t36; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t36 (
    id integer,
    name text
);


ALTER TABLE public.t36 OWNER TO nicuveo;

--
-- Name: t37; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t37 (
    id integer,
    name text
);


ALTER TABLE public.t37 OWNER TO nicuveo;

--
-- Name: t38; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t38 (
    id integer,
    name text
);


ALTER TABLE public.t38 OWNER TO nicuveo;

--
-- Name: t39; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t39 (
    id integer,
    name text
);


ALTER TABLE public.t39 OWNER TO nicuveo;

--
-- Name: t40; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t40 (
    id integer,
    name text
);


ALTER TABLE public.t40 OWNER TO nicuveo;

--
-- Name: t41; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t41 (
    id integer,
    name text
);


ALTER TABLE public.t41 OWNER TO nicuveo;

--
-- Name: t42; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t42 (
    id integer,
    name text
);


ALTER TABLE public.t42 OWNER TO nicuveo;

--
-- Name: t43; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t43 (
    id integer,
    name text
);


ALTER TABLE public.t43 OWNER TO nicuveo;

--
-- Name: t44; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t44 (
    id integer,
    name text
);


ALTER TABLE public.t44 OWNER TO nicuveo;

--
-- Name: t45; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t45 (
    id integer,
    name text
);


ALTER TABLE public.t45 OWNER TO nicuveo;

--
-- Name: t46; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t46 (
    id integer,
    name text
);


ALTER TABLE public.t46 OWNER TO nicuveo;

--
-- Name: t47; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t47 (
    id integer,
    name text
);


ALTER TABLE public.t47 OWNER TO nicuveo;

--
-- Name: t48; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t48 (
    id integer,
    name text
);


ALTER TABLE public.t48 OWNER TO nicuveo;

--
-- Name: t49; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t49 (
    id integer,
    name text
);


ALTER TABLE public.t49 OWNER TO nicuveo;

--
-- Name: t50; Type: TABLE; Schema: public; Owner: nicuveo
--

CREATE TABLE public.t50 (
    id integer,
    name text
);


ALTER TABLE public.t50 OWNER TO nicuveo;

--
-- Data for Name: hdb_action_log; Type: TABLE DATA; Schema: hdb_catalog; Owner: nicuveo
--

COPY hdb_catalog.hdb_action_log (id, action_name, input_payload, request_headers, session_variables, response_payload, errors, created_at, response_received_at, status) FROM stdin;
\.


--
-- Data for Name: hdb_cron_event_invocation_logs; Type: TABLE DATA; Schema: hdb_catalog; Owner: nicuveo
--

COPY hdb_catalog.hdb_cron_event_invocation_logs (id, event_id, status, request, response, created_at) FROM stdin;
\.


--
-- Data for Name: hdb_cron_events; Type: TABLE DATA; Schema: hdb_catalog; Owner: nicuveo
--

COPY hdb_catalog.hdb_cron_events (id, trigger_name, scheduled_time, status, tries, created_at, next_retry_at) FROM stdin;
\.


--
-- Data for Name: hdb_metadata; Type: TABLE DATA; Schema: hdb_catalog; Owner: nicuveo
--

COPY hdb_catalog.hdb_metadata (id, metadata, resource_version) FROM stdin;
1	{"sources":[{"configuration":{"connection_info":{"database_url":"postgres://localhost:4200/deep_rr","isolation_level":"read-committed","pool_settings":{"connection_lifetime":600,"idle_timeout":180,"max_connections":50,"retries":1},"use_prepared_statements":true}},"kind":"postgres","name":"default","tables":[{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t02","schema":"public"}}},"name":"r01"}],"table":{"name":"t01","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t04","schema":"public"}}},"name":"r03"}],"table":{"name":"t03","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t06","schema":"public"}}},"name":"r05"}],"table":{"name":"t05","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t08","schema":"public"}}},"name":"r07"}],"table":{"name":"t07","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t10","schema":"public"}}},"name":"r09"}],"table":{"name":"t09","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t12","schema":"public"}}},"name":"r11"}],"table":{"name":"t11","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t14","schema":"public"}}},"name":"r13"}],"table":{"name":"t13","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t16","schema":"public"}}},"name":"r15"}],"table":{"name":"t15","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t18","schema":"public"}}},"name":"r17"}],"table":{"name":"t17","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t20","schema":"public"}}},"name":"r19"}],"table":{"name":"t19","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t22","schema":"public"}}},"name":"r21"}],"table":{"name":"t21","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t24","schema":"public"}}},"name":"r23"}],"table":{"name":"t23","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t26","schema":"public"}}},"name":"r25"}],"table":{"name":"t25","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t28","schema":"public"}}},"name":"r27"}],"table":{"name":"t27","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t30","schema":"public"}}},"name":"r29"}],"table":{"name":"t29","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t32","schema":"public"}}},"name":"r31"}],"table":{"name":"t31","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t34","schema":"public"}}},"name":"r33"}],"table":{"name":"t33","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t36","schema":"public"}}},"name":"r35"}],"table":{"name":"t35","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t38","schema":"public"}}},"name":"r37"}],"table":{"name":"t37","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t40","schema":"public"}}},"name":"r39"}],"table":{"name":"t39","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t42","schema":"public"}}},"name":"r41"}],"table":{"name":"t41","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t44","schema":"public"}}},"name":"r43"}],"table":{"name":"t43","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t46","schema":"public"}}},"name":"r45"}],"table":{"name":"t45","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t48","schema":"public"}}},"name":"r47"}],"table":{"name":"t47","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"object","source":"default_2","table":{"name":"t50","schema":"public"}}},"name":"r49"}],"table":{"name":"t49","schema":"public"}}]},{"configuration":{"connection_info":{"database_url":"postgres://localhost:4200/deep_rr","isolation_level":"read-committed","use_prepared_statements":false}},"kind":"postgres","name":"default_2","tables":[{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t03","schema":"public"}}},"name":"r02"}],"table":{"name":"t02","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t05","schema":"public"}}},"name":"r04"}],"table":{"name":"t04","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t07","schema":"public"}}},"name":"r06"}],"table":{"name":"t06","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t09","schema":"public"}}},"name":"r08"}],"table":{"name":"t08","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t11","schema":"public"}}},"name":"r10"}],"table":{"name":"t10","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t13","schema":"public"}}},"name":"r12"}],"table":{"name":"t12","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t15","schema":"public"}}},"name":"r14"}],"table":{"name":"t14","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t17","schema":"public"}}},"name":"r16"}],"table":{"name":"t16","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t19","schema":"public"}}},"name":"r18"}],"table":{"name":"t18","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t21","schema":"public"}}},"name":"r20"}],"table":{"name":"t20","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t23","schema":"public"}}},"name":"r22"}],"table":{"name":"t22","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t25","schema":"public"}}},"name":"r24"}],"table":{"name":"t24","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t27","schema":"public"}}},"name":"r26"}],"table":{"name":"t26","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t29","schema":"public"}}},"name":"r28"}],"table":{"name":"t28","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t31","schema":"public"}}},"name":"r30"}],"table":{"name":"t30","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t33","schema":"public"}}},"name":"r32"}],"table":{"name":"t32","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t35","schema":"public"}}},"name":"r34"}],"table":{"name":"t34","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t37","schema":"public"}}},"name":"r36"}],"table":{"name":"t36","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t39","schema":"public"}}},"name":"r38"}],"table":{"name":"t38","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t41","schema":"public"}}},"name":"r40"}],"table":{"name":"t40","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t43","schema":"public"}}},"name":"r42"}],"table":{"name":"t42","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t45","schema":"public"}}},"name":"r44"}],"table":{"name":"t44","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t47","schema":"public"}}},"name":"r46"}],"table":{"name":"t46","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t49","schema":"public"}}},"name":"r48"}],"table":{"name":"t48","schema":"public"}},{"remote_relationships":[{"definition":{"to_source":{"field_mapping":{"id":"id"},"relationship_type":"array","source":"default","table":{"name":"t01","schema":"public"}}},"name":"r50"}],"table":{"name":"t50","schema":"public"}}]}],"version":3}	8
\.


--
-- Data for Name: hdb_scheduled_event_invocation_logs; Type: TABLE DATA; Schema: hdb_catalog; Owner: nicuveo
--

COPY hdb_catalog.hdb_scheduled_event_invocation_logs (id, event_id, status, request, response, created_at) FROM stdin;
\.


--
-- Data for Name: hdb_scheduled_events; Type: TABLE DATA; Schema: hdb_catalog; Owner: nicuveo
--

COPY hdb_catalog.hdb_scheduled_events (id, webhook_conf, scheduled_time, retry_conf, payload, header_conf, status, tries, created_at, next_retry_at, comment) FROM stdin;
\.


--
-- Data for Name: hdb_schema_notifications; Type: TABLE DATA; Schema: hdb_catalog; Owner: nicuveo
--

COPY hdb_catalog.hdb_schema_notifications (id, notification, resource_version, instance_id, updated_at) FROM stdin;
1	{"metadata":false,"remote_schemas":[],"sources":[]}	8	cb957379-4bf0-4a46-849f-43a1bf6fe231	2022-08-16 15:46:26.660174+01
\.


--
-- Data for Name: hdb_version; Type: TABLE DATA; Schema: hdb_catalog; Owner: nicuveo
--

COPY hdb_catalog.hdb_version (hasura_uuid, version, upgraded_on, cli_state, console_state) FROM stdin;
4fa80bfc-82cf-478f-a0f8-21e33f8b734b	47	2022-08-16 15:43:32.022655+01	{}	{"console_notifications": {"admin": {"date": "2022-08-16T14:45:54.906Z", "read": "default", "showBadge": false}}, "telemetryNotificationShown": true}
\.


--
-- Data for Name: t01; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t01 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t02; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t02 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t03; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t03 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t04; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t04 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t05; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t05 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t06; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t06 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t07; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t07 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t08; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t08 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t09; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t09 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t10; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t10 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t11; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t11 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t12; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t12 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t13; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t13 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t14; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t14 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t15; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t15 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t16; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t16 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t17; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t17 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t18; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t18 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t19; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t19 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t20; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t20 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t21; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t21 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t22; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t22 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t23; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t23 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t24; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t24 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t25; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t25 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t26; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t26 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t27; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t27 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t28; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t28 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t29; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t29 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t30; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t30 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t31; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t31 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t32; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t32 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t33; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t33 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t34; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t34 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t35; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t35 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t36; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t36 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t37; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t37 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t38; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t38 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t39; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t39 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t40; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t40 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t41; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t41 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t42; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t42 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t43; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t43 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t44; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t44 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t45; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t45 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t46; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t46 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t47; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t47 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t48; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t48 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t49; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t49 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Data for Name: t50; Type: TABLE DATA; Schema: public; Owner: nicuveo
--

COPY public.t50 (id, name) FROM stdin;
1	foo
2	foo
3	foo
4	foo
5	foo
6	foo
7	foo
8	foo
9	foo
10	foo
\.


--
-- Name: hdb_action_log hdb_action_log_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: nicuveo
--

ALTER TABLE ONLY hdb_catalog.hdb_action_log
    ADD CONSTRAINT hdb_action_log_pkey PRIMARY KEY (id);


--
-- Name: hdb_cron_event_invocation_logs hdb_cron_event_invocation_logs_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: nicuveo
--

ALTER TABLE ONLY hdb_catalog.hdb_cron_event_invocation_logs
    ADD CONSTRAINT hdb_cron_event_invocation_logs_pkey PRIMARY KEY (id);


--
-- Name: hdb_cron_events hdb_cron_events_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: nicuveo
--

ALTER TABLE ONLY hdb_catalog.hdb_cron_events
    ADD CONSTRAINT hdb_cron_events_pkey PRIMARY KEY (id);


--
-- Name: hdb_metadata hdb_metadata_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: nicuveo
--

ALTER TABLE ONLY hdb_catalog.hdb_metadata
    ADD CONSTRAINT hdb_metadata_pkey PRIMARY KEY (id);


--
-- Name: hdb_metadata hdb_metadata_resource_version_key; Type: CONSTRAINT; Schema: hdb_catalog; Owner: nicuveo
--

ALTER TABLE ONLY hdb_catalog.hdb_metadata
    ADD CONSTRAINT hdb_metadata_resource_version_key UNIQUE (resource_version);


--
-- Name: hdb_scheduled_event_invocation_logs hdb_scheduled_event_invocation_logs_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: nicuveo
--

ALTER TABLE ONLY hdb_catalog.hdb_scheduled_event_invocation_logs
    ADD CONSTRAINT hdb_scheduled_event_invocation_logs_pkey PRIMARY KEY (id);


--
-- Name: hdb_scheduled_events hdb_scheduled_events_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: nicuveo
--

ALTER TABLE ONLY hdb_catalog.hdb_scheduled_events
    ADD CONSTRAINT hdb_scheduled_events_pkey PRIMARY KEY (id);


--
-- Name: hdb_schema_notifications hdb_schema_notifications_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: nicuveo
--

ALTER TABLE ONLY hdb_catalog.hdb_schema_notifications
    ADD CONSTRAINT hdb_schema_notifications_pkey PRIMARY KEY (id);


--
-- Name: hdb_version hdb_version_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: nicuveo
--

ALTER TABLE ONLY hdb_catalog.hdb_version
    ADD CONSTRAINT hdb_version_pkey PRIMARY KEY (hasura_uuid);


--
-- Name: hdb_cron_event_invocation_event_id; Type: INDEX; Schema: hdb_catalog; Owner: nicuveo
--

CREATE INDEX hdb_cron_event_invocation_event_id ON hdb_catalog.hdb_cron_event_invocation_logs USING btree (event_id);


--
-- Name: hdb_cron_event_status; Type: INDEX; Schema: hdb_catalog; Owner: nicuveo
--

CREATE INDEX hdb_cron_event_status ON hdb_catalog.hdb_cron_events USING btree (status);


--
-- Name: hdb_cron_events_unique_scheduled; Type: INDEX; Schema: hdb_catalog; Owner: nicuveo
--

CREATE UNIQUE INDEX hdb_cron_events_unique_scheduled ON hdb_catalog.hdb_cron_events USING btree (trigger_name, scheduled_time) WHERE (status = 'scheduled'::text);


--
-- Name: hdb_scheduled_event_status; Type: INDEX; Schema: hdb_catalog; Owner: nicuveo
--

CREATE INDEX hdb_scheduled_event_status ON hdb_catalog.hdb_scheduled_events USING btree (status);


--
-- Name: hdb_version_one_row; Type: INDEX; Schema: hdb_catalog; Owner: nicuveo
--

CREATE UNIQUE INDEX hdb_version_one_row ON hdb_catalog.hdb_version USING btree (((version IS NOT NULL)));


--
-- Name: hdb_cron_event_invocation_logs hdb_cron_event_invocation_logs_event_id_fkey; Type: FK CONSTRAINT; Schema: hdb_catalog; Owner: nicuveo
--

ALTER TABLE ONLY hdb_catalog.hdb_cron_event_invocation_logs
    ADD CONSTRAINT hdb_cron_event_invocation_logs_event_id_fkey FOREIGN KEY (event_id) REFERENCES hdb_catalog.hdb_cron_events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hdb_scheduled_event_invocation_logs hdb_scheduled_event_invocation_logs_event_id_fkey; Type: FK CONSTRAINT; Schema: hdb_catalog; Owner: nicuveo
--

ALTER TABLE ONLY hdb_catalog.hdb_scheduled_event_invocation_logs
    ADD CONSTRAINT hdb_scheduled_event_invocation_logs_event_id_fkey FOREIGN KEY (event_id) REFERENCES hdb_catalog.hdb_scheduled_events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

